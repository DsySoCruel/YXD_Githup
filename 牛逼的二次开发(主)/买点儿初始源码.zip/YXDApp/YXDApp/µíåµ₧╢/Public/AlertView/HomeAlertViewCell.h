//
//  HomeAlertViewCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/20.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HomeAlertViewModel;

@interface HomeAlertViewCell : UITableViewCell

@property (nonatomic,strong) HomeAlertViewModel *model;

@end
