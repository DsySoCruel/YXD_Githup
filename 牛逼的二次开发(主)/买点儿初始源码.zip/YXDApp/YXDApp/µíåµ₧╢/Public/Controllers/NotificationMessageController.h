//
//  NotificationMessageController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/6.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "BaseViewController.h"

@interface NotificationMessageController : BaseViewController
@property (nonatomic,assign) BOOL isNeedSelect;//是否需要定位到系统消息
@end
