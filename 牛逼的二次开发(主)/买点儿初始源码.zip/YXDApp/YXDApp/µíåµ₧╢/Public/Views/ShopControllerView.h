//
//  ShopControllerView.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/4.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ShopHeadViewModel;

@interface ShopControllerView : UIView

@property (nonatomic,strong) ShopHeadViewModel *model;

@end
