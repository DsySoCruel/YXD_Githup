//
//  ShopControllerLeftCell.h
//  YXDApp
//
//  Created by daishaoyang on 2018/1/3.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ShopControllerSecondModel;

@interface ShopControllerLeftCell : UITableViewCell

@property (nonatomic,strong) ShopControllerSecondModel *model;

@end
