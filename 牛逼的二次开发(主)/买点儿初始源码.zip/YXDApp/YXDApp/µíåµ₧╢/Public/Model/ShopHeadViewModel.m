//
//  ShopHeadViewModel.m
//  YXDApp
//
//  Created by daishaoyang on 2018/6/15.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "ShopHeadViewModel.h"

@implementation ShopHeadViewModel

@end
