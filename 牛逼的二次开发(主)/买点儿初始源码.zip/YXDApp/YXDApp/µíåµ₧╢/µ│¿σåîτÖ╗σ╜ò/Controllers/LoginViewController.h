//
//  LoginViewController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/15.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

+ (YXDNavigationController *)shareLoginVC;

@property (nonatomic,assign) BOOL isNeedSelectIndexOne;

@end
