//
//  DSYPhotoModel.m
//  ParentsApp
//
//  Created by Mac book on 16/10/14.
//  Copyright © 2016年 WangShuo. All rights reserved.
//

#import "DSYPhotoModel.h"

@implementation DSYPhotoModel

@end
