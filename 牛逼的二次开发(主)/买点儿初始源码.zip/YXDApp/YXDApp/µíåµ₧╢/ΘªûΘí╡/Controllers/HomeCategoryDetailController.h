//
//  HomeCategoryDetailController.h
//  YXDApp
//
//  Created by daishaoyang on 2018/1/10.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeCategoryDetailController : BaseViewController

@property (nonatomic,strong) NSString *catId;

@end
