//
//  HomeTableViewCollectCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/7.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewModel.h"

@interface HomeTableViewCollectCell : UICollectionViewCell

@property (nonatomic,strong) HomeViewModelGoodList *model;

@end
