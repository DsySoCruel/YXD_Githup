//
//  HomeTableViewSonCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/20.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewModel.h"


@interface HomeTableViewSonCell : UITableViewCell

@property (nonatomic,strong) HomeViewModelTicket *model;

@end
