//
//  HomeIndustryModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/18.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeIndustryModel : NSObject

@property (nonatomic,strong) NSString *catId;
@property (nonatomic,strong) NSString *catName;
@property (nonatomic,strong) NSString *catPath;

@end
