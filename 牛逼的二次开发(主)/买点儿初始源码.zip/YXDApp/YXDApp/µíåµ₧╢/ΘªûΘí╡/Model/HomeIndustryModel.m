//
//  HomeIndustryModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/18.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "HomeIndustryModel.h"

@implementation HomeIndustryModel

@end
