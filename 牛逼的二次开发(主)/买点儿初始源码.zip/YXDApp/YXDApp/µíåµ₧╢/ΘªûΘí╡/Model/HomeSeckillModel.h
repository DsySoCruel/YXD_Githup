//
//  HomeSeckillModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/18.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeSeckillModel : NSObject

@property (nonatomic,strong) NSString *seckillId;
@property (nonatomic,strong) NSString *goodsId;
@property (nonatomic,strong) NSString *goodsName;
@property (nonatomic,strong) NSString *goodsStock;
@property (nonatomic,strong) NSString *saleCnt;
@property (nonatomic,strong) NSString *virtualBuyCnt;
@property (nonatomic,strong) NSString *goodsThums;
@property (nonatomic,strong) NSString *shopPrice;
@property (nonatomic,strong) NSString *startTime;
@property (nonatomic,strong) NSString *endTime;
@property (nonatomic,strong) NSString *shopName;
@property (nonatomic,strong) NSString *shopId;
@property (nonatomic,strong) NSString *panicMoney;

@end
