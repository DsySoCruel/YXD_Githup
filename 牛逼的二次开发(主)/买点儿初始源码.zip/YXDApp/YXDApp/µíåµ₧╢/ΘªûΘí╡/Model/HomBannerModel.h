//
//  HomBannerModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/18.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomBannerModel : NSObject

@property (nonatomic,strong) NSString *adId;
@property (nonatomic,strong) NSString *adName;
@property (nonatomic,strong) NSString *adURL;
@property (nonatomic,strong) NSString *adFile;

@end
