//
//  HomeSeckillModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/18.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "HomeSeckillModel.h"

@implementation HomeSeckillModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"seckillId" : @"id"};
}

@end
