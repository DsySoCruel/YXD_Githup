//
//  SelectWeizhiControllerModel.h
//  YXDApp
//
//  Created by daishaoyang on 2018/1/19.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SelectWeizhiControllerModel : NSObject

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *longitude;
@property (nonatomic,strong) NSString *latitude;
@property (nonatomic,strong) NSString *city;

@end
