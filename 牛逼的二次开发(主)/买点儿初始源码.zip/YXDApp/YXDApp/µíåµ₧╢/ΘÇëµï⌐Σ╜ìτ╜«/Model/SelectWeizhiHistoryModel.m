//
//  SelectWeizhiHistoryModel.m
//  YXDApp
//
//  Created by daishaoyang on 2018/2/6.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "SelectWeizhiHistoryModel.h"

@implementation SelectWeizhiHistoryModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"weizhiId" : @"id"};
}


@end
