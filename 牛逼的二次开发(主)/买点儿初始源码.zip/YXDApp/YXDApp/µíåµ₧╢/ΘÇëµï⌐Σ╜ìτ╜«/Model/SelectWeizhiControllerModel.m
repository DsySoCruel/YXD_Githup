//
//  SelectWeizhiControllerModel.m
//  YXDApp
//
//  Created by daishaoyang on 2018/1/19.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "SelectWeizhiControllerModel.h"

@implementation SelectWeizhiControllerModel

@end
