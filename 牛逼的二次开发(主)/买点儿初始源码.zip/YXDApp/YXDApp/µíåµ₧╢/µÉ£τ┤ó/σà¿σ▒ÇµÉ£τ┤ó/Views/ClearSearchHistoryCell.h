//
//  ClearSearchHistoryCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/23.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClearSearchHistoryCell : UITableViewCell

- (void)configureCell;

+ (instancetype)cellWithTableView:(UITableView *)tableView;


@end
