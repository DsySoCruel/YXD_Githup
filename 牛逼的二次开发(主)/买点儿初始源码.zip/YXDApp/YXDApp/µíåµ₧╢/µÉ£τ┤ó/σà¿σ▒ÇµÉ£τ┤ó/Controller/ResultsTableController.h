//
//  ResultsTableController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/23.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultsTableController : UITableViewController

@property (nonatomic,strong) NSMutableArray *dataSourceArray;

@property (nonatomic,strong) UINavigationController *nav;

@end
