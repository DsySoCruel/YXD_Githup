//
//  SearchTableViewController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/23.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchTableViewController : BaseViewController

@property (nonatomic,strong) NSString *keyWord;//搜索关键字

@end
