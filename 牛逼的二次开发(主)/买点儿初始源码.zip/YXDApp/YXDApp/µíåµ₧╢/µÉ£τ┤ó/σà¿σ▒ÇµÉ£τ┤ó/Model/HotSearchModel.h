//
//  HotSearchModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/23.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HotSearchModel : NSObject

@property (nonatomic,strong) NSString *searchText;

@property (nonatomic,strong) NSString *seaNum;

@end
