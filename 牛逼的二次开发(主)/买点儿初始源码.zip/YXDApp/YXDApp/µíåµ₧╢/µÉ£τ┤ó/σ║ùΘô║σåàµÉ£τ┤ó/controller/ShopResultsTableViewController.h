//
//  ShopResultsTableViewController.h
//  YXDApp
//
//  Created by daishaoyang on 2018/6/20.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopResultsTableViewController : UITableViewController
@property (nonatomic,strong) NSMutableArray *dataSourceArray;
@property (nonatomic,strong) UINavigationController *nav;
@end
