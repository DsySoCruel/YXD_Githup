//
//  ShopSearchDisplayController.h
//  YXDApp
//
//  Created by daishaoyang on 2018/6/19.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "BaseViewController.h"

@interface ShopSearchDisplayController : BaseViewController
@property (nonatomic,strong) NSString *shopId;
@end
