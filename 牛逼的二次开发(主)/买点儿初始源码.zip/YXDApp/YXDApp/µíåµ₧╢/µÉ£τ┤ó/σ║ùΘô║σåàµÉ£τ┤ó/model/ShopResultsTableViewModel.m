//
//  ShopResultsTableViewModel.m
//  YXDApp
//
//  Created by daishaoyang on 2018/6/20.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "ShopResultsTableViewModel.h"

@implementation ShopResultsTableViewModel

@end
