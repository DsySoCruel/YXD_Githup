//
//  RefreshFooterView.h
//  YXDApp
//
//  Created by daishaoyang on 2018/5/14.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface RefreshFooterView : MJRefreshBackGifFooter

@end
