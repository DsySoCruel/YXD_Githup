//
//  CategoryTableVIewCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/20.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CategoryTableVIewModel;

@interface CategoryTableVIewCell : UITableViewCell

@property (nonatomic,strong) CategoryTableVIewModel *model;

@end
