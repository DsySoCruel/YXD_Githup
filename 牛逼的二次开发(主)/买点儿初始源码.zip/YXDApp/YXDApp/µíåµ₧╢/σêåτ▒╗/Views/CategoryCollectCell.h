//
//  CategoryCollectCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/20.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryCollecModel.h"

@interface CategoryCollectCell : UICollectionViewCell

@property (nonatomic,strong) CategoryCollecDataModel *collecModel;

@end
