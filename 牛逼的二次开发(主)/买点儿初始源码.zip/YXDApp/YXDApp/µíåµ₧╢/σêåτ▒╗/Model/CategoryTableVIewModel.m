//
//  CategoryTableVIewModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/11/21.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "CategoryTableVIewModel.h"

@implementation CategoryTableVIewModel

@end
