//
//  MyCommentControllerCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/17.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyCommentModel;

@interface MyCommentControllerCell : UITableViewCell

@property (nonatomic,strong) MyCommentModel *model;

@end
