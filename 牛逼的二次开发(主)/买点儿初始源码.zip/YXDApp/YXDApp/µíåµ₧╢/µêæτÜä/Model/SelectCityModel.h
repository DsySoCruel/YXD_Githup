//
//  SelectCityModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/11.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SelectCityModel : NSObject
//"areaId": "659004403",
//"areaName": "\u5317\u4eac\u5e02"

@property (nonatomic,strong) NSString *areaId;
@property (nonatomic,strong) NSString *areaName;

@end
