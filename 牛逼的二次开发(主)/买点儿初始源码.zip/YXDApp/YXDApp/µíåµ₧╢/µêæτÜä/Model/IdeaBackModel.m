//
//  IdeaBackModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/15.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "IdeaBackModel.h"

@implementation IdeaBackModel

@end
