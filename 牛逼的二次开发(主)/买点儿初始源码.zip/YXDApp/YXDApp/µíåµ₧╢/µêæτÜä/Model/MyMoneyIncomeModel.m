//
//  MyMoneyIncomeModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/14.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "MyMoneyIncomeModel.h"

@implementation MyMoneyIncomeModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"moneyId" : @"id"};
}


@end
