//
//  SelectCityModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/11.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "SelectCityModel.h"

@implementation SelectCityModel




@end
