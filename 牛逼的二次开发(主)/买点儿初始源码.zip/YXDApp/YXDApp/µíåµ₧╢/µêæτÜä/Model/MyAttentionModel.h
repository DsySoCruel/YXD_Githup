//
//  MyAttentionModel.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/13.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyAttentionModel : NSObject

@property (nonatomic,strong) NSString *favoriteId;
@property (nonatomic,strong) NSString *shopId;
@property (nonatomic,strong) NSString *shopName;
@property (nonatomic,strong) NSString *shopImg;
@property (nonatomic,strong) NSString *deliveryType;
@property (nonatomic,strong) NSString *deliveryCostTime;
@property (nonatomic,strong) NSString *star;
@property (nonatomic,strong) NSString *sale;

@end
