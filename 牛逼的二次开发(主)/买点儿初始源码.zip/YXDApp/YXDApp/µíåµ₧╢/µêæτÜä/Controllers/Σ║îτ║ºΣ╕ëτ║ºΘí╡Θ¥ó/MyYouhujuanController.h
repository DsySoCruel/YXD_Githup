//
//  MyYouhujuanController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/16.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyYouhujuanController : BaseViewController

@end
