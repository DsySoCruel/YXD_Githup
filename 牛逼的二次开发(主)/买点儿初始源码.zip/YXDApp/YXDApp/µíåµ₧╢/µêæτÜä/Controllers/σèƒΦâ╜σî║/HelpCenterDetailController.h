//
//  HelpCenterDetailController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/14.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "BaseViewController.h"

@interface HelpCenterDetailController : BaseViewController

@property (nonatomic,strong) NSString *articleId;

@end
