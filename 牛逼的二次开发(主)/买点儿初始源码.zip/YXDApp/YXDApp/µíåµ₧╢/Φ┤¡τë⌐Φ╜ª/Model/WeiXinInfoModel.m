//
//  WeiXinInfoModel.m
//  YXDApp
//
//  Created by daishaoyang on 2018/3/19.
//  Copyright © 2018年 beijixing. All rights reserved.
//

#import "WeiXinInfoModel.h"

@implementation WeiXinInfoModel

@end
