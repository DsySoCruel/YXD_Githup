//
//  ShopCarDetailModel.m
//  YXDApp
//
//  Created by daishaoyang on 2017/12/27.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "ShopCarDetailModel.h"

@implementation ShopCarDetailGoodsModel

@end

@implementation ShopCarDetailCarsGoodModel

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"shopgoods" : [ShopCarDetailGoodsModel class]};
}

@end

@implementation ShopCarDetailModel

@end
