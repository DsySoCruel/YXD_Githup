//
//  ShopCarViewCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/11/21.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ShopCarViewModel;

@interface ShopCarViewCell : UITableViewCell

@property (nonatomic,strong)ShopCarViewModel *model;

@end
