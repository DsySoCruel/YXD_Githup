//
//  OrderProducFirstCollectionCell.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/28.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class OrderProducCouponModel;

@interface OrderProducFirstCollectionCell : UICollectionViewCell

@property (nonatomic,strong) OrderProducCouponModel *model;

@end
