//
//  OrderProducController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/24.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "BaseViewController.h"
#import "OrderProducModel.h"

@interface OrderProducController : BaseViewController

@property (nonatomic,strong) OrderProducModel *model;

@property (nonatomic,strong) NSString *shopId;

@end
