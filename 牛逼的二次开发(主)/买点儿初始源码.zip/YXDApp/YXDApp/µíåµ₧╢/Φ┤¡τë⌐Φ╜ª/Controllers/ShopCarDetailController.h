//
//  ShopCarDetailController.h
//  YXDApp
//
//  Created by daishaoyang on 2017/12/26.
//  Copyright © 2017年 beijixing. All rights reserved.
//

#import "BaseViewController.h"
@class ShopCarViewModel;

@interface ShopCarDetailController : BaseViewController

@property (nonatomic,strong) NSString *shopId;

//@property (nonatomic, copy) void(^deletSuccessBlock)(void);

@end
