//
//  UMSocialSinaHandler.h
//  UMSocialSDK
//
//  Created by wyq.Cloudayc on 2/21/17.
//  Copyright © 2017 UMeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMShare/UMShare.h>

@interface UMSocialSinaHandler : UMSocialHandler

+ (UMSocialSinaHandler *)defaultManager;


@end
